/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adell;

import adell.view.PelangganView;

/**
 *
 * @author AzrulRochmad
 */
public class JOptionPane {

    public static void showMessageDialog(PelangganView view, String nama_Masih_Kosong) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
